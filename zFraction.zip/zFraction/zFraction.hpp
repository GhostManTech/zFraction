#if !defined(__ZFRACTION_HPP_INCLUDED__)
#define __ZFRACTION_HPP_INCLUDED__

#include <tuple>
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <string>

int random(int min, int max);
void randomTable(int min, int max);
int biggest(int a, int b);
int leastBig(int a, int b);
int abs(int value);

std::string repeat(int n, std::string var);
void add(int value, int numerator, int denominator, std::string *num, std::string *den, std::string *line);
std::tuple<int, int, std::string, std::string, std::string> optimizeFraction(int numerator, int denominator);

#endif