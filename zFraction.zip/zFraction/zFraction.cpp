#include "zFraction.hpp"

int random(int min, int max){
	int nb1 = 0, nb2 = 0, result = 0;
	if(min > max){
		nb1 = max;
		nb2 = min;
	}
	else if(min == max){
		nb1 = 0;
		nb2 = 10;
	}
	else{
		nb1 = min;
		nb2 = max;
	}
	result = rand()%(nb2+1-nb1)+nb1;
	return result;
}

void randomTable(int min, int max){
	srand(time(0));
	static int table[10];
	for(int i = 0; i < 10; ++i){
		table[i] = random(min, max);
		std::cout << table[i] << std::endl;
	}
}

int biggest(int a, int b){
	if(a >= b)
		return a;
	else
		return b;
}

int leastBig(int a, int b){
	if(a <= b)
		return a;
	else
		return b;
}

int abs(int value){
	if(value == 0)
		return 0;
	else if(value < 0)
		return value*(-1);
	else
		return value;
}

std::string repeat(int n, std::string var){
	std::string res = "";
	for(int k = 0; k < n; ++k){
		res += var;
	}
	return res;
}

void add(int value, int numerator, int denominator, std::string *num, std::string *den, std::string *line){
	std::string i1 = std::to_string(numerator) + " x " + std::to_string(value);
	std::string i2 = std::to_string(denominator) + " x " + std::to_string(value);
	int i = biggest(i1.length(), i2.length());
	std::string i3 = " = " + repeat(i, "-");
	*num += repeat(3, " ") + i1;
	*den += repeat(3, " ") + i2;
	*line += i3;
	if(i1.length() <= i)
		*num += repeat(i-i1.length(), " ");
	if(i2.length() <= i)
		*den += repeat(i-i2.length(), " ");

	i1 = std::to_string(numerator);
	i2 = std::to_string(denominator);
	i = biggest(i1.length(), i2.length());
	i3 = " = " + repeat(i, "-");
	*line += i3;
	*num += repeat(3, " ") + i1;
	*den += repeat(3, " ") + i2;
	if(i1.length() <= i)
		*num += repeat(i-i1.length(), " ");
	if(i2.length() <= i)
		*den += repeat(i-i2.length(), " ");
}

std::tuple<int, int, std::string, std::string, std::string> optimizeFraction(int numerator, int denominator){
	int value = 0, i = 1;
	std::string num = std::to_string(numerator), den = std::to_string(denominator);
	std::string line = repeat(biggest(num.length(), den.length()), "-");
	if(numerator < 0 || denominator < 0){
		while(i > 0){
			i = 0;
			for(value = abs(leastBig(numerator, denominator)); value > 1; --value){
				if(numerator % value == 0 && denominator % value == 0){
					numerator /= value;
					denominator /= value;
					++i;
					add(value, numerator, denominator, &num, &den, &line);
				}
			}
		}
	}
	else{
		while(i > 0){
			i = 0;
			for(value = biggest(numerator, denominator); value > 1; --value)
				if(numerator % value == 0 && denominator % value == 0){
					numerator /= value;
					denominator /= value;
					++i;
					add(value, numerator, denominator, &num, &den, &line);
				}
		}
	}
	std::tuple<int, int, std::string, std::string, std::string> res = std::make_tuple(numerator, denominator, num, line, den);
	return res;
}